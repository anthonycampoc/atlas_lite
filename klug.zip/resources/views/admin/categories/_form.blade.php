 
                    <div class="form-group">
                      <label for="exampleInputName1">Nombre</label>
                      <input type="text" class="form-control form-control-lg" id="exampleInputName1" name="name" required>
                    </div>

                    <div class="form-group">
                      <label for="exampleInputName1">Descripción</label>
                      <input type="text" class="form-control  form-control-lg" id="exampleInputName1" name="description" required>
                    </div>
                   
                  
           